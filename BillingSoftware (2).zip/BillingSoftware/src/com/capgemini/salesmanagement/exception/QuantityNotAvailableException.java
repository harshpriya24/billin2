package com.capgemini.salesmanagement.exception;

public class QuantityNotAvailableException  extends Exception{

	public QuantityNotAvailableException() {
		super();
	}

	public QuantityNotAvailableException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public QuantityNotAvailableException(String message, Throwable cause) {
		super(message, cause);
	}

	public QuantityNotAvailableException(String message) {
		super(message);
	}

	public QuantityNotAvailableException(Throwable cause) {
		super(cause);
	}

}
