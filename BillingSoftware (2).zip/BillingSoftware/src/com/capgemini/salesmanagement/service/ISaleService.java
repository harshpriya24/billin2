package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;

public interface ISaleService {
	public HashMap<Integer,Sale> insertSalesDetails(Sale sale) throws ProductNotFoundException;
	public boolean validateProductCode(int productId) throws ProductNotFoundException;
	boolean validateQuantity(int qty) throws ProductNotFoundException;
	public boolean validateProductCat(String prodCat) throws ProductNotFoundException;
	public boolean validateProductPrice(float price) throws ProductNotFoundException;
    
}
