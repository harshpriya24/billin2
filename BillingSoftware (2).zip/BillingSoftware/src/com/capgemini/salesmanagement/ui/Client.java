package com.capgemini.salesmanagement.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.exception.ProductNotFoundException;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {
	public static void main(String args[]) {
		ISaleService services=new SaleService();
		int i=1;
		int index;
		while(i<=3) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter 1 to insert sales");
			System.out.println("Enter 2 to validate the product code");
			System.out.println("Enter 3to validate the quantity");
			System.out.println("Enter 4 to validate the product category");
			System.out.println("Enter 5 to validate product price");
			System.out.println("Enter 6 to display the bill");
			index=sc.nextInt();
			switch(index) {
			case 1:System.out.println("to insert sales");
			try {
				System.out.println("Enter the product Id");
				int prodCode=sc.nextInt();
				
				System.out.println("Enter the Quantity");
				int quantity=sc.nextInt();
				;
				System.out.println("Enter Product Category");
				String category=sc.next();
				
				System.out.println("Product Name");
				String productName=sc.next();
				System.out.println("Enter Product Description");
				String description=sc.next();
				System.out.println("Enter Price");
				int price=sc.nextInt();
				float lineTotal=price*quantity;
				if(services.validateProductCode(prodCode)==true&&
						services.validateQuantity(quantity)==true&&services.validateProductCat(category)==true&&services.validateProductPrice(price)==true
				) {
				Sale sale=new Sale(prodCode, productName, category,quantity, lineTotal);
				services.insertSalesDetails(sale);
			    System.out.println("Sale inserted");
				}
				else
				{
					System.out.println("Enter valid info");
				}
			} catch (ProductNotFoundException e) {
				e.printStackTrace();
			}
             break;
			case 2:System.out.println("to validate the prodcode"); 
			System.out.println("Enter the Product code");
			int prodCode=sc.nextInt();
			try {
				boolean result=services.validateProductCode(prodCode);
				if(result==true)
					System.out.println("Product code valid");
				else
					System.out.println("Product code not valid");
			} catch (ProductNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			case 3: System.out.println("To validate the quantity");
			try {
				int quantity=sc.nextInt();
				boolean result2=services.validateQuantity(quantity);
				if(result2==true)
					System.out.println("Quantity valid");
				else
					System.out.println("Quantity not valid");
			} catch (ProductNotFoundException e) {
				e.printStackTrace();
			}
			break;
			case 4: System.out.println("To validate product category");
			try {
				System.out.println("Enter product Category ");
				String prodCat=sc.next();
				boolean result3=services.validateProductCat(prodCat);
				if(result3==true)
					System.out.println("Category  valid");
			
			} catch (ProductNotFoundException e) {
				e.printStackTrace();
			}
			break;
			case 5: System.out.println("To validate product price");
                    System.out.println("Enter the price");
			try {
				int price= sc.nextInt();
				boolean result4=services.validateProductPrice(price);
				if(result4==true)
					System.out.println("Price  valid");
	

			} catch (ProductNotFoundException e) {
				e.printStackTrace();
			}
			break;
			case 6:System.out.println("To generate bill enter the details");

			try {
				System.out.println("Enter the product Id");
				int prodCod=sc.nextInt();
				System.out.println("Enter the Quantity");
				int quantity=sc.nextInt();
				System.out.println("Enter Product Category");
				String category=sc.next();
				System.out.println("Product Name");
				String productName=sc.next();
				System.out.println("Enter Product Description");
				String description=sc.next();
				System.out.println("Enter Price");
				int price=sc.nextInt();
				float lineTotal=price*quantity;
				if(services.validateProductCode(prodCod)==true&&
						services.validateQuantity(quantity)==true&&services.validateProductCat(category)==true&&services.validateProductPrice(price)==true
				) {
				Sale sale=new Sale(prodCod, productName, category,quantity, lineTotal);
				HashMap<Integer, Sale> insertSales=services.insertSalesDetails(sale);

				// Getting a Set of Key-value pairs
				Set entrySet = insertSales.entrySet();
				// Obtaining an iterator for the entry set
				Iterator it = entrySet.iterator();
				while(it.hasNext()){
					Map.Entry me = (Map.Entry)it.next();
					System.out.println("Key is: "+me.getKey() + 
							" & " + 
							" value is: "+me.getValue());
				}
				}
			} catch (ProductNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			}


		}

	}
}
